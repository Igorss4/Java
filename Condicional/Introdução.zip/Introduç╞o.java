package Condicional;

import java.util.Scanner;

public class Introdu��o {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		String x;
		int y,y1;
		boolean ajudarVelho;
		
		System.out.println("Bem vindo aventureiro");
		System.out.println("Para prosseguir aperte 'A'");
		x=ler.next();
		System.out.println("'Aventureiro, nossa vila precisa de agua, poderia ir buscar para nos ajudar?'");
		x=ler.next();
		System.out.println("'Existe um rio logo depois da floresta, leve este balde... aahh..\n"
				+ "monstros costumam aparecer por la, tenha cuidado'");
		x=ler.next();
		System.out.println("...'SAINDO DA VILA'...");
		x=ler.next();
		System.out.println("'Psiu... Voce aii.. '");
		x=ler.next();
		System.out.println("Eu ?");
		x=ler.next();
		System.out.println("'Isso.. Voce parece forte, destemido, tenho algo pra voce.."
				+ "\nMas s� se me ajudar...'");
		x=ler.next();
		System.out.println("E pra que quer minha ajuda?");
		x=ler.next();
		System.out.println("'Meu filho se perdeu na caverna proximo ao rio, poderia ir encontra-lo?'");
		x=ler.next();
		System.out.println("O que ganho com isso?");
		x=ler.next();
		System.out.println("'Pode escolher um desses 3 itens'");
		x=ler.next();
		System.out.println("'Vai me ajudar?'");
		x=ler.next();
		System.out.println("DIGITE '1' PARA SIM E '2' PARA NAO");
		y=ler.nextInt();
		if(y==1) {
			System.out.println("'Ainda bem que posso contar com voce'");
			x=ler.next();
		System.out.println("'Aqui... Escolha seu item..'");
		System.out.println("1-ESPADA.\n2-ARCO.\n3-CAJADO.");
		y1=ler.nextInt();
		if(y1==1) {
			System.out.println("Voce escolheu a ESPADA");
		x=ler.next();	}
		else if(y1==2) {
			System.out.println("Voce escolheu o ARCO");
		x=ler.next();	}
		else if(y1==3) {
			System.out.println("Voce escolheu o CAJADO");
		x=ler.next();	}
		System.out.println("'Boa escolha jovem, a caverna fica logo apos a floresta..."
				+ " Boa sorte...'");
		x=ler.next();
		}
		else if(y==2)
			System.out.println("'Entendo, vou encontrar alguem para me ajudar");
		System.out.println("!!!!!FIM DO JOGO!!!!!!");
		
		
		
			
			
		
			
		
		
	}
}
